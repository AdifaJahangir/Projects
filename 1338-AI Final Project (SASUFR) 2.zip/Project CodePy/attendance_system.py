import cv2
import os
import glob
import numpy as np
from datetime import datetime
import openpyxl

# Define paths
training_data_path = r'E:\5TH SEMESTER\AI 5th Project\AI Final Project (SASUFR)\Project CodePy\tariningData'
model_train = r'E:\5TH SEMESTER\AI 5th Project\AI Final Project (SASUFR)\Project CodePy\face_recognizer_model.yml'

# Face recognizer
recognizer = cv2.face.LBPHFaceRecognizer_create()

# Load known faces and their labels
faces = []
labels = []
label_dict = {}
current_id = 0

#  Path Haar Cascade file
cascade_path = r'D:\ana\envs\envpython9\Lib\site-packages\haarcascade_frontalface_default.xml'

# All image files in the training data 
image_paths = glob.glob(os.path.join(training_data_path, "*.jpg"))

for image_path in image_paths:
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        print(f"Unable to read image: {image_path}")
        continue
    
    filename = os.path.basename(image_path)
    try:
        name, reg_no = filename.split('_')[:2]  
        label = f"{name}_{reg_no}"
    except ValueError as e:
        print(f"Filename {filename} is not in the correct format: {e}")
        continue
    
    if label not in label_dict:
        label_dict[label] = current_id
        current_id += 1
    
    faces.append(img)
    labels.append(label_dict[label])

# Convert labels to a numpy array
labels = np.array(labels)

# Train the recognizer
if len(faces) > 0 and len(labels) > 0:
    recognizer.train(faces, labels)
    recognizer.save(model_train) 
else:
    print("Not enough training data. Please add more images.")
    exit()

excel_file = r'E:\5TH SEMESTER\AI 5th Project\AI Final Project (SASUFR)\Project CodePy\attendance.xlsx'

def mark_attendance(excel_file):
    try:
        workbook = openpyxl.load_workbook(excel_file)
        sheet = workbook.active
    except FileNotFoundError:
        workbook = openpyxl.Workbook()
        sheet = workbook.active
        sheet.append(["Date", "Name", "Reg No", "Status"])
    return workbook, sheet

def process_video(excel_file):
    try:
        workbook, sheet = mark_attendance(excel_file)
        video_capture = cv2.VideoCapture(0)
        marked_attendance = set()  

        while True:
            ret, frame = video_capture.read()
            if not ret:
                print("Unable to capture video.")
                continue
            
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            detected_faces = cv2.CascadeClassifier(cascade_path).detectMultiScale(gray, 1.3, 5)

            for (x, y, w, h) in detected_faces:
                face_img = gray[y:y+h, x:x+w]
                label, confidence = recognizer.predict(face_img)

                if confidence < 50:  
                    name_reg_no = list(label_dict.keys())[list(label_dict.values()).index(label)]
                    name, reg_no = name_reg_no.split('_')

                    cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                    cv2.rectangle(frame, (x, y - 35), (x + w, y), (0, 255, 0), cv2.FILLED)
                    font = cv2.FONT_HERSHEY_DUPLEX
                    cv2.putText(frame, f"{name} ({reg_no})", (x + 6, y - 6), font, 1.0, (255, 255, 255), 1)

                    current_date = datetime.now().strftime("%Y-%m-%d")
                    if (current_date, reg_no) not in marked_attendance:
                        row = (current_date, name, reg_no, "P")  
                        sheet.append(row)
                        marked_attendance.add((current_date, reg_no))  
                        workbook.save(excel_file)
                        print(f"Attendance recorded for {name} ({reg_no}).")

                else:
                    cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)
                    cv2.rectangle(frame, (x, y - 35), (x + w, y), (0, 0, 255), cv2.FILLED)
                    font = cv2.FONT_HERSHEY_DUPLEX
                    cv2.putText(frame, "Unknown", (x + 6, y - 6), font, 1.0, (255, 255, 255), 1)

            cv2.imshow('Video', frame)

            # Stop when 'b' is pressed
            if cv2.waitKey(1) & 0xFF == ord('b'):
                print("Stopping...")
                break

    except KeyboardInterrupt:
        print("Interrupt received. Exiting gracefully...")

    finally:
        if video_capture.isOpened():
            video_capture.release()
        cv2.destroyAllWindows()
        print("Video stopped, resources released.")



