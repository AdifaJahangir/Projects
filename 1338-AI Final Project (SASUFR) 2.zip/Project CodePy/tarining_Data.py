import cv2
import os

# Define paths
training_data_path = r'E:\5TH SEMESTER\AI 5th Project\AI Final Project (SASUFR)\Project CodePy\tariningData'
os.makedirs(training_data_path, exist_ok=True)
cascade_path = r'D:\ana\envs\envpython9\Lib\site-packages\haarcascade_frontalface_default.xml'

# Function to capture and save images for a single user
def capture_user_images():
    name = input("Enter the user's name: ")
    reg_no = input("Enter the user's registration number: ")
    
    # Initialize the webcam
    video_capture = cv2.VideoCapture(0)
    num_faces = 5 
    new_dimension = (200, 200)

    for i in range(num_faces):
        ret, frame = video_capture.read()
        if not ret:
            continue
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = cv2.CascadeClassifier(cascade_path).detectMultiScale(gray, 1.3, 5)

        for (x, y, w, h) in faces:
            cropped_face = frame[y:y+h, x:x+w]
            resized_face = cv2.resize(cropped_face, new_dimension)
            gray_face = cv2.cvtColor(resized_face, cv2.COLOR_BGR2GRAY)
            path = os.path.join(training_data_path, f"{name}_{reg_no}_{i}.jpg")
            cv2.imwrite(path, gray_face)
            cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
            cv2.putText(frame, f"Capturing {i+1}/{num_faces}", (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 0, 0), 2)
        
        cv2.imshow('Register User', frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    video_capture.release()
    cv2.destroyAllWindows()
    print(f"Captured images for {name} (Reg No: {reg_no})")

capture_user_images()
