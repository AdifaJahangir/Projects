import streamlit as st
import pandas as pd
import os
from attendance_system import process_video

# Set page title
st.set_page_config(
    page_title="NTU Smart Attendance System",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    body {
        font-family: 'Arial', sans-serif;
    }
    .main-header {
        background: linear-gradient(to right, #003566, #0077B6);
        padding: 20px;
        border-radius: 12px;
        text-align: center;
        color: white;
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
    }
    .main-header h1 {
        margin: 0;
        font-size: 42px;
    }
    .main-header p {
        margin: 0;
        font-size: 18px;
        color: #d0eaff;
    }
    .sidebar-title {
        font-size: 20px;
        font-weight: bold;
        color: #0077B6;
    }
    .footer {
        text-align: center;
        margin-top: 20px;
        font-size: 14px;
        color: gray;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# Hero Header
st.markdown(
    """
    <div class="main-header">
        <h1>NTU Smart Attendance System 🎓</h1>
        <p>Streamlining attendance with advanced AI-powered facial recognition.</p>
    </div>
    """,
    unsafe_allow_html=True,
)

# Sidebar Navigation
st.sidebar.markdown('<div class="sidebar-title">🔍 Navigation</div>', unsafe_allow_html=True)
app_mode = st.sidebar.radio(
    "Choose an option:",
    ["🏠 Home", "📝 Mark Attendance", "📊 Show Attendance"],
)

# Define the path to your attendance Excel file
excel_file = r'E:\5TH SEMESTER\AI 5th Project\AI Final Project (SASUFR)\Project CodePy\attendance.xlsx'

# Home Page
if app_mode == "🏠 Home":
    col1, col2 = st.columns([2, 1])
    with col1:
        st.markdown(
            """
            <div style="margin-top: 30px;">
                <h1 style="color:#003566; font-size: 32px; font-weight: bold;">Welcome to NTU Smart Attendance System</h1>
                <p style="font-size:16px; color:#555;">
                    Experience seamless and efficient attendance management with our AI-powered solution.
                    Navigate through the sidebar to mark or view attendance records effortlessly.
                </p>
            </div>
            """,
            unsafe_allow_html=True,
        )
    # with col2:
    #     st.image(
    #         "https://picsum.photos/300/200",
    #         caption="AI-Powered Attendance",
    #         use_container_width=True,
    #     )
    st.info("💡 To get started, choose an option from the sidebar!")

# Mark Attendance Page
elif app_mode == "📝 Mark Attendance":
    st.markdown(
        """
        <h1 style="color:#0077B6; font-size: 28px;">📝 Mark Attendance</h1>
        <p style="color:#555; font-size:16px;">Click the button below to start the face detection process and mark attendance.</p>
        """,
        unsafe_allow_html=True,
    )
    if st.button("🚀 Start Mark Attendance", key="mark_attendance"):
        with st.spinner("Processing... Please wait for the face detection to complete."):
            process_video(excel_file)
        st.success("✅ Attendance has been marked successfully!")

# Show Attendance Page
elif app_mode == "📊 Show Attendance":
    st.markdown(
        """
        <h1 style="color:#0077B6; font-size:28px;">📊 Attendance Records</h1>
        <p style="color:#555; font-size:16px;">Review the attendance records below. Use the slider to customize the number of rows displayed.</p>
        """,
        unsafe_allow_html=True,
    )

    if os.path.exists(excel_file):
        num_rows = st.slider("Select the number of rows to display:", 5, 50, 10, key="rows_slider")
        df = pd.read_excel(excel_file)
        st.dataframe(df.head(num_rows), use_container_width=True)
        st.success(f"Showing the first {num_rows} rows of attendance records.")
    else:
        st.warning("⚠️ No attendance records found. Please mark attendance first!")

# Footer
st.markdown(
    """
    <hr>
    <div class="footer">
        <p>© 2024 NTU | Built with Team Breaker using Streamlit</p>
    </div>
    """,
    unsafe_allow_html=True,
)


